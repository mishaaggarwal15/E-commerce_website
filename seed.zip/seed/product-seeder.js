var Product = require('../models/product');

var mongoose = require('mongoose');
mongoose.connect('mongodb+srv://siddharth:nakli274@cluster0.sjzyc.mongodb.net/<dbname>?retryWrites=true&w=majority', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
  .then(() => console.log('Connected to DB!'))
  .catch(error => console.log(error.message));

var products = [
    new Product({
        imagePath: 'https://www.apple.com/newsroom/images/product/mac/standard/Apple_16-inch-MacBook-Pro_111319_big.jpg.large.jpg',
        title: 'MacBook Pro 15.6-Inch',
        description: 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
        price: 121999
    }),
    new Product({
        imagePath: 'https://i.pcmag.com/imagery/reviews/03xdTO0Ka4H4KvEgtSPg4c2-12.1569479325.fit_lpad.size_625x365.jpg',
        title: 'Asus-Rog Phone 3',
        description: 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
        price: 41499
    }),
    new Product({
        imagePath: 'https://www.apple.com/newsroom/images/product/mac/standard/Apple_new-macbook-air-wallpaper-screen_03182020_big.jpg.large.jpg',
        title: 'MacBook Air 13-Inch',
        description: 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
        price: 91999
    }),
    new Product({
        imagePath: 'https://global.canon/ja/c-museum/wp-content/uploads/2020/07/dcc884_top.jpg',
        title: 'Canon D-2400',
        description: 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
        price: 15999
    }),
    new Product({
        imagePath: 'https://www.lg.com/in/images/mobile-phones/md06155757/gallery/Platinum_07-1100-V3.jpg',
        title: 'LG W30 Triple Camera',
        description: 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
        price: 25499
    }),
    new Product({
        imagePath: 'https://i.gadgets360cdn.com/products/laptops/large/1546457015_635_apple_macbook-air-mrea2hn-a.jpg',
        title: 'MacBook-Pro 13-Inch',
        description: 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
        price: 11699
    }),
];

var done = 0;
for (var i = 0; i < products.length; i++) {
    products[i].save(function(err, result) {
        done++;
        if (done === products.length) {
            exit();
        }
    });
}

function exit() {
    mongoose.disconnect();
}